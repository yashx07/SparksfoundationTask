SPARKS INETRNSHIP

Task 1- Prediction using Supervised ML 
Main task is to predict about percentage of an student based on the no. of study hours. 

Task3- Exploratory Data Analysis - Retail
